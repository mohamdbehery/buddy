#!/usr/bin/env bash

FINGERPRINT=""

 if [ -f ~/.ssh/google_compute_engine.pub ]
 then 
    PUB_KEY=$(awk '{print $2}' ~/.ssh/google_compute_engine.pub)
    FINGERPRINT=$(gcloud compute os-login describe-profile --format json | jq -r --arg KEY $PUB_KEY '.sshPublicKeys[] | select((.key |= split(" ")) | .key[1] == $KEY) | .fingerprint')
 else
   echo NO SSH KEYS FOUND, NOTHING TO CLEAN
   exit 0
 fi

if [ "$FINGERPRINT" != "" ]
then
  echo DELETING SSH PUBLIC KEY FROM OS-LOGIN PROFILE
  echo KEY_ID: $FINGERPRINT
  gcloud compute os-login ssh-keys remove --key=$FINGERPRINT
  
  echo REMOVING LOCAL SSH KEYS
  rm -f ~/.ssh/google_compute_engine*  
 fi 
