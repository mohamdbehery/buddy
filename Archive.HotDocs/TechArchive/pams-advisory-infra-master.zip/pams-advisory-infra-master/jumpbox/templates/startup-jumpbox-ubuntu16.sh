#!/bin/bash
#
# Startup script for Ubuntu 16
#
# Optional terraform template variables to configure github credentials:
#   GITHUB_SVC_USERNAME = TF_VAR_GITHUB_SVC_USERNAME
#   GITHUB_SVC_TOKEN = TF_VAR_GITHUB_SVC_TOKEN
# If either value is empty then github credentials will not be configured.
#
# Optional terraform template variables override Google metadata values:
#   MY_PROJECT_ID = TF_VAR_PROJECT
#   MY_ZONE = TF_VAR_ZONE
#   MY_SERVICE_ACCOUNT_EMAIL = TF_VAR_SERVICE_ACCOUNT_EMAIL
#

_DEFAULT_ANSIBLE_VERSION="2.7.13"

_bt=$SECONDS
echo "#### startup-script started"

##############################################################################
## signal startup script START
date '+%s' > /etc/startup-script-start
##############################################################################


##############################################################################
## install packages
apt update
apt -y install \
    curl \
    wget \
    tar \
    zip \
    unzip \
    jq \
    netcat \
    git \
    google-cloud-sdk \
    python-pip \
    python3-pip \
    libssl-dev

echo "#### packages installed"
##############################################################################


# ##############################################################################
# ## install pip ansible package(s)
# pip install \
#     requests \
#     google-auth

# echo "#### pip packages installed"
# ##############################################################################


##############################################################################
## collect required values
MY_HOSTNAME=$(hostname)

if [ -n "${TF_VAR_PROJECT}" ]; then
    MY_PROJECT_ID="${TF_VAR_PROJECT}"
else
    MY_PROJECT_ID=$(curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/project/project-id)
fi

if [ -n "${TF_VAR_ZONE}" ]; then
    MY_ZONE="${TF_VAR_ZONE}"
else
    MY_ZONE=$(curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/zone | cut -d / -f 4)
fi

if [ -n "${TF_VAR_SERVICE_ACCOUNT_EMAIL}" ]; then
    MY_SERVICE_ACCOUNT_EMAIL="${TF_VAR_SERVICE_ACCOUNT_EMAIL}"
else
    MY_SERVICE_ACCOUNT_EMAIL=$(curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/email)
fi

if [ -n "${TF_VAR_ANSIBLE_VERSION}" ]; then
  MY_ANSIBLE_VERSION="${TF_VAR_ANSIBLE_VERSION}"
else
  MY_ANSIBLE_VERSION="$_DEFAULT_ANSIBLE_VERSION"
fi

GITHUB_SVC_USERNAME="${TF_VAR_GITHUB_SVC_USERNAME}"
GITHUB_SVC_TOKEN="${TF_VAR_GITHUB_SVC_TOKEN}"

echo
echo "#### using configuration values:"
echo "#    MY_HOSTNAME: $MY_HOSTNAME"
echo "#    MY_PROJECT_ID: $MY_PROJECT_ID"
echo "#    MY_ZONE: $MY_ZONE"
echo "#    MY_SERVICE_ACCOUNT_EMAIL: $MY_SERVICE_ACCOUNT_EMAIL"
echo "#    MY_ANSIBLE_VERSION: $MY_ANSIBLE_VERSION"
echo "#    GITHUB_SVC_USERNAME: $GITHUB_SVC_USERNAME"
echo "#    GITHUB_SVC_TOKEN: ****"
echo
##############################################################################

##############################################################################
## generate SA ssh keypair
mkdir -p ~/.ssh
chmod 700 ~/.ssh

gcloud compute ssh $MY_HOSTNAME --quiet --force-key-file-overwrite --zone "$MY_ZONE" --project "$MY_PROJECT_ID" --internal-ip --command whoami

SA_USERNAME=$(gcloud compute ssh $MY_HOSTNAME --quiet --zone "$MY_ZONE" --project "$MY_PROJECT_ID" --internal-ip --command 'echo "SA_USERNAME=$USER"' | grep '^SA_USERNAME' | cut -d = -f 2)

if [ -z "$SA_USERNAME" ]; then
    echo "#### ERROR - could not discover service account username, aborting"
    exit 1
fi

echo "#### discovered service account username: $SA_USERNAME"
##############################################################################


##############################################################################
## setup ansible user and env
if id ansible &>/dev/null; then
    echo "ansible user already exists"
else
    useradd -c ansible -m ansible
fi

##############################################################################
## install pip ansible package(s)
if [ "$MY_ANSIBLE_VERSION" = "latest" ]; then
  su -l ansible -c "pip install --user ansible"
else
  su -l ansible -c "pip install --user \"ansible==$MY_ANSIBLE_VERSION\""
fi

echo "#### pip packages installed"
##############################################################################

##############################################################################
## install pip ansible package(s)
su -l ansible -c "pip install --user --upgrade \\
    requests \\
    google-auth \\
    cachetools==3.1.1 \\
    pywinrm"

echo "#### pip packages installed"
##############################################################################

# TODO - setup .bashrc and/or .bash_profile

echo "#### ansible user and environment created and configured"
##############################################################################


##############################################################################
## setup ansible user ssh keypair and config
mkdir ~ansible/.ssh

cat > ~ansible/.ssh/config <<EOF
Host *
  Port 22
  User $SA_USERNAME
  StrictHostKeyChecking no
  IdentitiesOnly yes
  IdentityFile ~/.ssh/id_rsa
EOF

tar -C ~/.ssh -cf - . | (cd ~ansible/.ssh/. && tar xvf -)
ln -f -sv google_compute_engine ~ansible/.ssh/id_rsa
ln -f -sv google_compute_engine.pub ~ansible/.ssh/id_rsa.pub

chmod -R u=rwX,go-rwx ~ansible/.ssh/.
chown -R ansible:ansible ~ansible/.ssh/.

echo "#### ansible ssh keypair installed and configured"
##############################################################################


##############################################################################
## setup ansible config and plugin(s)
cat - > ~ansible/ansible.cfg <<EOF
[defaults]
host_key_checking = False

[inventory]
enable_plugins = gcp_compute
ignore_extensions = .pyc, .pyo, .swp, .bak, ~, .rpm, .md, .txt, ~, .orig, .ini, .cfg, .retry
EOF
chown ansible:ansible ~ansible/ansible.cfg

cat - > ~ansible/inventory.gcp.yml <<EOF
plugin: gcp_compute
projects:
    - $MY_PROJECT_ID
keyed_groups:
    - key: labels.application
hostnames:
    - name
filters:
auth_kind: machineaccount
service_account_email: $MY_SERVICE_ACCOUNT_EMAIL
EOF
chown ansible:ansible ~ansible/inventory.gcp.yml

echo "#### ansible dynamic inventory configured"
##############################################################################


##############################################################################
## setup github credentials (if available)
if [ -n "$GITHUB_SVC_USERNAME" -a -n "$GITHUB_SVC_TOKEN" ]; then
    cat - > ~ansible/.netrc <<EOF
machine github.com
login  $GITHUB_SVC_USERNAME
password $GITHUB_SVC_TOKEN
EOF

    chmod 600 ~ansible/.netrc
    chown ansible:ansible ~ansible/.netrc

    echo "#### github credentials configured"
else
    echo "#### github credentials configuration skipped (no github credentials configured)"
fi
##############################################################################

##############################################################################
## workaround to enable shutdown scripts invocation: specify active syslog service
## name in the unit file /lib/systemd/system/google-shutdown-scripts.service 
CURRENT_SYSLOG_SERVICE=$(systemctl list-units --state=active -t service | grep -i "system log" | awk '{print $1}')
echo "### Current syslog daemon: $${CURRENT_SYSLOG_SERVICE}"
LOG_SERVICE=$(grep -e 'log.*\.service' /lib/systemd/system/google-shutdown-scripts.service | sed -e 's/^.* \([^ ]*log.*\.service\)/\1/')
echo "### LOG service google-shutdown-scripts depend on: $${LOG_SERVICE}"

if [ "$${LOG_SERVICE}" != "$${CURRENT_SYSLOG_SERVICE}" ]
 then 
 echo "### FIXING SYSLOG SERVICE DEPENDENCY: $${LOG_SERVICE} -> $${CURRENT_SYSLOG_SERVICE}"
 sed -i -e "s/$${LOG_SERVICE}/$${CURRENT_SYSLOG_SERVICE}/" /lib/systemd/system/google-shutdown-scripts.service 
 echo "### RELOADING SYSTEMD DAEMON"
 systemctl daemon-reload 
  else 
  echo "### NO NEED TO REPLACE ANYTHING"
fi
##############################################################################

##############################################################################
## signal of startup script COMPLETE
# TODO - A better signalling mechanism would be nice here.
#      - Eg. Something like AWS CloudFormation's signalling mechanisms.

date '+%s' > /etc/startup-script-complete
##############################################################################

_et=$SECONDS
_dt=$((_et - _bt))
echo "#### startup-script complete, approx runtime: $_dt sec"
