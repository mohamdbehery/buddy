#!/bin/bash
#
# Startup script for RHEL7/Centos7
#
# Optional terraform template variables to configure github credentials:
#   GITHUB_SVC_USERNAME = TF_VAR_GITHUB_SVC_USERNAME
#   GITHUB_SVC_TOKEN = TF_VAR_GITHUB_SVC_TOKEN
# If either value is empty then github credentials will not be configured.
#
# Optional terraform template variables override Google metadata values:
#   MY_PROJECT_ID = TF_VAR_PROJECT
#   MY_ZONE = TF_VAR_ZONE
#   MY_SERVICE_ACCOUNT_EMAIL = TF_VAR_SERVICE_ACCOUNT_EMAIL
#

_DEFAULT_ANSIBLE_VERSION="2.7.13"

_bt=$SECONDS
echo "#### startup-script started"

##############################################################################
## signal startup script START
date '+%s' > /etc/startup-script-start
##############################################################################


##############################################################################
## add google cloud sdk repo
tee -a /etc/yum.repos.d/google-cloud-sdk.repo << EOM
[google-cloud-sdk]
name=Google Cloud SDK
baseurl=https://packages.cloud.google.com/yum/repos/cloud-sdk-el7-x86_64
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://packages.cloud.google.com/yum/doc/yum-key.gpg
       https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
EOM

echo "#### google-cloud-sdk yum repo added"
##############################################################################


##############################################################################
## install packages
yum -y install \
    curl \
    wget \
    tar \
    zip \
    unzip \
    jq \
    nmap-ncat \
    git \
    google-cloud-sdk \
    python2-pip

echo "#### packages installed"
##############################################################################


##############################################################################
## install pip ansible dependency package(s)
#move to after ansible user is installed
# pip install \
#     requests \
#     google-auth

# echo "#### pip packages installed"
##############################################################################


##############################################################################
## collect required values
MY_HOSTNAME=$(hostname)

if [ -n "${TF_VAR_PROJECT}" ]; then
    MY_PROJECT_ID="${TF_VAR_PROJECT}"
else
    MY_PROJECT_ID=$(curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/project/project-id)
fi

if [ -n "${TF_VAR_ZONE}" ]; then
    MY_ZONE="${TF_VAR_ZONE}"
else
    MY_ZONE=$(curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/zone | cut -d / -f 4)
fi

if [ -n "${TF_VAR_SERVICE_ACCOUNT_EMAIL}" ]; then
    MY_SERVICE_ACCOUNT_EMAIL="${TF_VAR_SERVICE_ACCOUNT_EMAIL}"
else
    MY_SERVICE_ACCOUNT_EMAIL=$(curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/email)
fi

if [ -n "${TF_VAR_ANSIBLE_VERSION}" ]; then
  MY_ANSIBLE_VERSION="${TF_VAR_ANSIBLE_VERSION}"
else
  MY_ANSIBLE_VERSION="$_DEFAULT_ANSIBLE_VERSION"
fi

GITHUB_SVC_USERNAME="${TF_VAR_GITHUB_SVC_USERNAME}"
GITHUB_SVC_TOKEN="${TF_VAR_GITHUB_SVC_TOKEN}"

echo
echo "#### using configuration values:"
echo "#    MY_HOSTNAME: $MY_HOSTNAME"
echo "#    MY_PROJECT_ID: $MY_PROJECT_ID"
echo "#    MY_ZONE: $MY_ZONE"
echo "#    MY_SERVICE_ACCOUNT_EMAIL: $MY_SERVICE_ACCOUNT_EMAIL"
echo "#    MY_ANSIBLE_VERSION: $MY_ANSIBLE_VERSION"
echo "#    GITHUB_SVC_USERNAME: $GITHUB_SVC_USERNAME"
echo "#    GITHUB_SVC_TOKEN: ****"
echo
##############################################################################


##############################################################################
## generate SA ssh keypair
mkdir -p ~/.ssh
chmod 700 ~/.ssh

gcloud compute ssh $MY_HOSTNAME --quiet --force-key-file-overwrite --zone "$MY_ZONE" --project "$MY_PROJECT_ID" --internal-ip --command whoami

SA_USERNAME=$(gcloud compute ssh $MY_HOSTNAME --quiet --zone "$MY_ZONE" --project "$MY_PROJECT_ID" --internal-ip --command 'echo "SA_USERNAME=$USER"' | grep '^SA_USERNAME' | cut -d = -f 2)

if [ -z "$SA_USERNAME" ]; then
    echo "#### ERROR - could not discover service account username, aborting"
    exit 1
fi

echo "#### discovered service account username: $SA_USERNAME"
##############################################################################


##############################################################################
## setup ansible user and env
if id ansible &>/dev/null; then
    echo "ansible user already exists"
else
    useradd -c ansible -m ansible
fi

##############################################################################
## install pip ansible package(s)
if [ "$MY_ANSIBLE_VERSION" = "latest" ]; then
    su -l ansible -c 'pip install --user ansible'
else
    su -l ansible -c "pip install --user ansible==$MY_ANSIBLE_VERSION"
fi

# RHEL7: need to update python2-setuptools
pip install -U setuptools

echo "#### pip packages installed"
##############################################################################

## workaround to overcome permission issues with accessing python site-packages for ansible user
su -l ansible -c 'pip install --user --upgrade --force-reinstall requests google-auth cachetools==3.1.1 pywinrm' 

# TODO - setup .bashrc and/or .bash_profile

echo "#### ansible user and environment created and configured"
##############################################################################


##############################################################################
## setup ansible user ssh keypair and config
mkdir ~ansible/.ssh

cat > ~ansible/.ssh/config <<EOF
Host *
  Port 22
  User $SA_USERNAME
  StrictHostKeyChecking no
  IdentitiesOnly yes
  IdentityFile ~/.ssh/id_rsa
EOF

tar -C ~/.ssh -cf - . | (cd ~ansible/.ssh/. && tar xvf -)
ln -f -sv google_compute_engine ~ansible/.ssh/id_rsa
ln -f -sv google_compute_engine.pub ~ansible/.ssh/id_rsa.pub

chmod -R u=rwX,go-rwx ~ansible/.ssh/.
chown -R ansible:ansible ~ansible/.ssh/.

echo "#### ansible ssh keypair installed and configured"
##############################################################################


##############################################################################
## setup ansible config and plugin(s)
cat - > ~ansible/ansible.cfg <<EOF
[defaults]
host_key_checking = False

[inventory]
enable_plugins = gcp_compute
ignore_extensions = .pyc, .pyo, .swp, .bak, ~, .rpm, .md, .txt, ~, .orig, .ini, .cfg, .retry
EOF
chown ansible:ansible ~ansible/ansible.cfg

cat - > ~ansible/inventory.gcp.yml <<EOF
plugin: gcp_compute
projects:
    - $MY_PROJECT_ID
keyed_groups:
    - key: labels.application
hostnames:
    - name
filters:
auth_kind: machineaccount
service_account_email: $MY_SERVICE_ACCOUNT_EMAIL
EOF
chown ansible:ansible ~ansible/inventory.gcp.yml

echo "#### ansible dynamic inventory configured"
##############################################################################


##############################################################################
## setup github credentials (if available)
if [ -n "$GITHUB_SVC_USERNAME" -a -n "$GITHUB_SVC_TOKEN" ]; then
    cat - > ~ansible/.netrc <<EOF
machine github.com
login  $GITHUB_SVC_USERNAME
password $GITHUB_SVC_TOKEN
EOF

    chmod 600 ~ansible/.netrc
    chown ansible:ansible ~ansible/.netrc

    echo "#### github credentials configured"
else
    echo "#### github credentials configuration skipped (no github credentials configured)"
fi
##############################################################################


##############################################################################
## signal of startup script COMPLETE
# TODO - A better signalling mechanism would be nice here.
#      - Eg. Something like AWS CloudFormation's signalling mechanisms.

date '+%s' > /etc/startup-script-complete
##############################################################################

_et=$SECONDS
_dt=$((_et - _bt))
echo "#### startup-script complete, approx runtime: $_dt sec"
