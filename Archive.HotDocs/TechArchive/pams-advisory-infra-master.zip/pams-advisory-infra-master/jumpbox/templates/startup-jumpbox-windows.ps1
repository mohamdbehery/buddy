#
# Windows jumpbox startup script.
#
[CmdletBinding()]
Param()
