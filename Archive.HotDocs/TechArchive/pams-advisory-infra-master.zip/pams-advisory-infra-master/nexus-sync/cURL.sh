#!/bin/bash

#######################################################
#### Put *.csv files from repository to the bucket ####
#######################################################

# set directory vars for artifacts to be downloaded
mapArtifactDest=/home/builder
manifestDest=./nexus-sync/Manifests
artifactDest=/home/builder/Artifacts

# Set bucket name value per environment
if [ $TARGET_ENV == "dev" ]
then
    bucket="files-sbx"
    # set sub env value for 'sbx' env due to sharing same bucket with 'dev'
    subenv="sbx"
elif [ $TARGET_ENV == "uat" ]
then
    bucket="clgx-advisorypor-cache-files-uat"
elif [ $TARGET_ENV == "reg" ]
then
    bucket="clgx-advisorypor-cache-files-reg"
    # set sub env value for 'drg' env due to sharing same bucket with 'reg'
    subenv="drg"
else
    echo "No matching bucket for the environment received."
fi

# backup old objects with current date and time
beforeDate=`date +%Y%m%d-%H:%M`
gsutil mv gs://$bucket/Manifests/$TARGET_ENV-artifact-map.csv gs://$bucket/Manifests/before-$beforeDate-$TARGET_ENV-artifact-map.csv
gsutil mv gs://$bucket/Manifests/$TARGET_ENV-manifest.csv gs://$bucket/Manifests/before-$beforeDate-$TARGET_ENV-manifest.csv
gsutil mv gs://$bucket/Manifests/$subenv-manifest.csv gs://$bucket/Manifests/before-$beforeDate-$subenv-manifest.csv

# upload new files from repo
gsutil -m cp -r -n $manifestDest/$TARGET_ENV-artifact-map.csv gs://$bucket/Manifests/
gsutil -m cp -r -n $manifestDest/$TARGET_ENV-manifest.csv gs://$bucket/Manifests/
gsutil -m cp -r -n $manifestDest/$subenv-manifest.csv gs://$bucket/Manifests/

############################################
#### Download artifacts from Nexus repo ####
############################################

# create '/home/builder/Artifacts' folder
mkdir $artifactDest

# sign artifact-map.csv file
INPUT=$manifestDest/$TARGET_ENV-artifact-map.csv
while IFS=, read -r group name version path extension
do
    # if the fisrt character in line is "#" - skip the line
    if [[ ${group:0:1} != "#" ]] ; then

        # change "." to "/" for a group
        group=${group//./$'/'}

        # remove hidden symbol in the end of the line
        extension=${extension/[$'\t\r\n']/''}

        # make the path to the artifact in Nexus
        artifactName=$name-$version.$extension
        artifactPath=https://repo2.corelogic.net/repository/advisory-m2-releases/$group/$name/$version/$artifactName

        # get the artifact from the Nexus
        wget -O $artifactDest/$artifactName $artifactPath

        # upload artifact to GCP Bucket
        gsutil -m cp -r -n $artifactDest/$artifactName gs://$bucket/$path/

        fi

done < $INPUT

