 This example will create the instance(s) and assign the ip addresses that you provide

but 2 things will happen: 

1. You dont know for sure that the IP address that you are providing is available for you. 

2. If it is it will get destroy when the machine gets destroy by another modification in terraform i.e startup script changes.  

The best practice for this it to use the terraform-gcp-reserve-ip instance and once you reserve it  then you will know for sure what ip address will be available and so you can assign them and wont be destroyed after a terraform destroy.

