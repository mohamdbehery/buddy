## Note: The module is WIP, it may not work as expected, better use the folder for basewindows

This script creates  managed instance groups in required regions.
Configuration details are passed to terraform script using .tfvar files.
For required regions create a per region .tfvars files and pass this to the tf
script. Refer to us-west1.tfvars and variable.tf for details of each variable.

To run the script , follow below steps

run terraform command as below

`terraform init -backend-config="environments/{environmentname}/{regionname}.config" -backend-config="environments/{environmentname}/{environmentname}.config"`

- this command will initialize the backend data for the specific region and environment where the AD server will be hydrated. The environment config file holds data that is explicit for the environment. In this example, the persistent storage name is in the sandbox config file. All the state files for the AD servers will be saved to this one persistent storage. The regionname config file hold the path to the individual statefiles for each AD server. Since each AD server is hydrated individually, there needs to be an individual statefile.

`terraform init -backend-config="env/sbx/sandbox.config" -backend-config="env/sbx/jump-server.config"`

`terraform plan -var-file="env/sbx/sandbox.tfvars" -var-file="env/sbx/jump-server.tfvars"`

`terraform apply -var-file="env/sbx/sandbox.tfvars" -var-file="env/sbx/jump-server.tfvars"`

`terraform destroy -var-file=-var-file="env/sbx/sandbox.tfvars" -var-file="env/sbx/jump-server.tfvars"`

### Dev

`terraform init -backend-config="env/dev/dev.config" -backend-config="env/dev/jump-server.config"`

`terraform plan -var-file="env/dev/dev.tfvars" -var-file="env/dev/jump-server.tfvars"`

`terraform apply -var-file="env/dev/dev.tfvars" -var-file="env/dev/jump-server.tfvars"`


- state file for each of this workspace is stored  in 'clgx-mft-ad-sbx-terraform-state/ad/{regionname}/default.tfstate' bucket
