#!/bin/bash
set -euxo pipefail

update() {
  apt-get update
  apt-get upgrade
}

main () {
	update
  echo "[*] apt-get update done."
}

main "$@"
