# Terraform for Static IPs

Static IPs are currently spawned before Load balancers.

The load balancer module used by each VM type is hardcoded to expect Static IPs with a lookup.

As required, once these IP's are created we will request Solutions.Corelogic.com records to point to them.

## Important note

> The terraform code has been enabled to prevent the destruction of these IPs. Once they are created, the goal is to keep them up and running for as long as Advisory is running.

**Keep in mind:**
The core automation modules require static IP's to enable the load balancers, yet they aren't required by the architecture. So eventually we should deprecate these and use the builtin dns from the load balancers to save money and simplify resource sprawl.

Source: https://cloud.google.com/load-balancing/docs/dns-names

## List the IPs generated in your environment

```gcloud compute addresses list```

## Provisioning in JKCI

Even though the IPs will be generated once and then they'll be kept reserved indefinitely, there is a Jenkins pipeline for it.
Once created, you’ll see 2 options:

a. When creating, the pipeline will display the IPs and its names again, no changes will be made

b. When the destroy command is triggered, the pipeline will fail executing the apply phase, with an error like this:

> Error running plan: 7 errors occurred:
	* google_compute_address.reserve_internal_ip[2]: google_compute_address.reserve_internal_ip: the plan would destroy this resource, but it currently has lifecycle.prevent_destroy set to true. To avoid this error and continue with the plan, either disable lifecycle.prevent_destroy or adjust the scope of the plan using the -target flag.

## Provisioning by environment

To review the IPs that were generated, use the following command in the correspondig project and region:

### Sandbox
No IPs should be provisioned in SBX from this project. Look into the root of the fixedips repo for the reference on this one.

### DEV

`terraform init -backend-config="environments/dev/dev.config" -backend-config="environments/dev/us-central1.config"`

`terraform plan -var-file="environments/dev/dev.tfvars" -var-file="environments/dev/us-central1.tfvars"`

`terraform apply -var-file="environments/dev/dev.tfvars" -var-file="environments/dev/us-central1.tfvars"`

`terraform destroy -var-file="environments/dev/dev.tfvars" -var-file="environments/dev/us-central1.tfvars"`

### UAT

`terraform init -backend-config="environments/uat/uat.config" -backend-config="environments/uat/us-central1.config"`

`terraform plan -var-file="environments/uat/uat.tfvars" -var-file="environments/uat/us-central1.tfvars"`

`terraform apply -var-file="environments/uat/uat.tfvars" -var-file="environments/uat/us-central1.tfvars"`

`terraform destroy -var-file="environments/uat/uat.tfvars" -var-file="environments/uat/us-central1.tfvars"`

### PROD

`terraform init -backend-config="environments/reg/reg.config" -backend-config="environments/reg/us-central1.config"`

`terraform plan -var-file="environments/reg/reg.tfvars" -var-file="environments/reg/us-central1.tfvars"`

`terraform apply -var-file="environments/reg/reg.tfvars" -var-file="environments/reg/us-central1.tfvars"`

`terraform destroy -var-file="environments/reg/reg.tfvars" -var-file="environments/reg/us-central1.tfvars"`

### DRG

`terraform init -backend-config="environments/drg/drg.config" -backend-config="environments/drg/us-west1.config"`

`terraform plan -var-file="environments/drg/drg.tfvars" -var-file="environments/drg/us-west1.tfvars"`

`terraform apply -var-file="environments/drg/drg.tfvars" -var-file="environments/drg/us-west1.tfvars"`

`terraform destroy -var-file="environments/drg/drg.tfvars" -var-file="environments/drg/us-west1.tfvars"`