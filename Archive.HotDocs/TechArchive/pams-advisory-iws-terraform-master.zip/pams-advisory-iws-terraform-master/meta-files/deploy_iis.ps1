# Support -Verbose option
[CmdletBinding()]

Param (
    [string]$SubjectName = $env:COMPUTERNAME,
    [int]$CertValidityDays = 1095,
    [switch]$SkipNetworkProfileCheck,
    $CreateSelfSignedCert = $true,
    [switch]$ForceNewSSLCert,
    [switch]$GlobalHttpFirewallAccess,
    [switch]$DisableBasicAuth = $false,
    [switch]$EnableCredSSP
)

$OutputFileLocation = "C:\MyLogs-$(get-date -uformat '%Y-%m-%d-%H_%M').log"
$reboot = 'false'

Function Write-Log {
    #removing for now
    # $Message = $args[0]
    # Write-EventLog -LogName Application -Source $EventSource -EntryType Information -EventId 1 -Message $Message
    # Add-Content $OutputFileLocation "$(get-date -uformat '%Y-%m-%d %H:%M') $Message"
}

Function Write-VerboseLog {
    $Message = $args[0]
    Write-Verbose $Message
    Write-Log $Message
    Add-Content $OutputFileLocation "$(get-date -uformat '%Y-%m-%d %H:%M') $Message"
}

Function Write-HostLog {
    $Message = $args[0]
    Write-Output $Message
    Write-Log $Message
    Add-Content $OutputFileLocation "$(get-date -uformat '%Y-%m-%d %H:%M') $Message"
}

Function New-LegacySelfSignedCert {
    Param (
        [string]$SubjectName,
        [int]$ValidDays = 1095
    )
    Write-VerboseLog "Setting up self-signed cert"
    $hostnonFQDN = $env:computerName
    $hostFQDN = [System.Net.Dns]::GetHostByName(($env:computerName)).Hostname
    $SignatureAlgorithm = "SHA256"

    $name = New-Object -COM "X509Enrollment.CX500DistinguishedName.1"
    $name.Encode("CN=$SubjectName", 0)

    $key = New-Object -COM "X509Enrollment.CX509PrivateKey.1"
    $key.ProviderName = "Microsoft Enhanced RSA and AES Cryptographic Provider"
    $key.KeySpec = 1
    $key.Length = 4096
    $key.SecurityDescriptor = "D:PAI(A;;0xd01f01ff;;;SY)(A;;0xd01f01ff;;;BA)(A;;0x80120089;;;NS)"
    $key.MachineContext = 1
    $key.Create()

    $serverauthoid = New-Object -COM "X509Enrollment.CObjectId.1"
    $serverauthoid.InitializeFromValue("1.3.6.1.5.5.7.3.1")
    $ekuoids = New-Object -COM "X509Enrollment.CObjectIds.1"
    $ekuoids.Add($serverauthoid)
    $ekuext = New-Object -COM "X509Enrollment.CX509ExtensionEnhancedKeyUsage.1"
    $ekuext.InitializeEncode($ekuoids)

    $cert = New-Object -COM "X509Enrollment.CX509CertificateRequestCertificate.1"
    $cert.InitializeFromPrivateKey(2, $key, "")
    $cert.Subject = $name
    $cert.Issuer = $cert.Subject
    $cert.NotBefore = (Get-Date).AddDays(-1)
    $cert.NotAfter = $cert.NotBefore.AddDays($ValidDays)

    $SigOID = New-Object -ComObject X509Enrollment.CObjectId
    $SigOID.InitializeFromValue(([Security.Cryptography.Oid]$SignatureAlgorithm).Value)

    [string[]] $AlternativeName += $hostnonFQDN
    $AlternativeName += $hostFQDN
    $IAlternativeNames = New-Object -ComObject X509Enrollment.CAlternativeNames

    foreach ($AN in $AlternativeName) {
        $AltName = New-Object -ComObject X509Enrollment.CAlternativeName
        $AltName.InitializeFromString(0x3, $AN)
        $IAlternativeNames.Add($AltName)
    }

    $SubjectAlternativeName = New-Object -ComObject X509Enrollment.CX509ExtensionAlternativeNames
    $SubjectAlternativeName.InitializeEncode($IAlternativeNames)

    [String[]]$KeyUsage = ("DigitalSignature", "KeyEncipherment")
    $KeyUsageObj = New-Object -ComObject X509Enrollment.CX509ExtensionKeyUsage
    $KeyUsageObj.InitializeEncode([int][Security.Cryptography.X509Certificates.X509KeyUsageFlags]($KeyUsage))
    $KeyUsageObj.Critical = $true

    $cert.X509Extensions.Add($KeyUsageObj)
    $cert.X509Extensions.Add($ekuext)
    $cert.SignatureInformation.HashAlgorithm = $SigOID
    $CERT.X509Extensions.Add($SubjectAlternativeName)
    $cert.Encode()

    $enrollment = New-Object -COM "X509Enrollment.CX509Enrollment.1"
    $enrollment.InitializeFromRequest($cert)
    $certdata = $enrollment.CreateRequest(0)
    $enrollment.InstallResponse(2, $certdata, 0, "")

    # extract/return the thumbprint from the generated cert
    $parsed_cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
    $parsed_cert.Import([System.Text.Encoding]::UTF8.GetBytes($certdata))
    Write-VerboseLog "Self signed cert set up complete"
    return $parsed_cert.Thumbprint
}

Function Enable-GlobalHttpFirewallAccess {
    Write-VerboseLog "Forcing global HTTP firewall access"
    # this is a fairly naive implementation; could be more sophisticated about rule matching/collapsing
    $fw = New-Object -ComObject HNetCfg.FWPolicy2

    # try to find/enable the default rule first
    $add_rule = $false
    $matching_rules = $fw.Rules | ? { $_.Name -eq "Windows Remote Management (HTTP-In)" }
    $rule = $null
    If ($matching_rules) {
        If ($matching_rules -isnot [Array]) {
            Write-VerboseLog "Editing existing single HTTP firewall rule"
            $rule = $matching_rules
        }
        Else {
            # try to find one with the All or Public profile first
            Write-VerboseLog "Found multiple existing HTTP firewall rules..."
            $rule = $matching_rules | % { $_.Profiles -band 4 }[0]

            If (-not $rule -or $rule -is [Array]) {
                Write-VerboseLog "Editing an arbitrary single HTTP firewall rule (multiple existed)"
                # oh well, just pick the first one
                $rule = $matching_rules[0]
            }
        }
    }

    If (-not $rule) {
        Write-VerboseLog "Creating a new HTTP firewall rule"
        $rule = New-Object -ComObject HNetCfg.FWRule
        $rule.Name = "Windows Remote Management (HTTP-In)"
        $rule.Description = "Inbound rule for Windows Remote Management via WS-Management. [TCP 5985]"
        $add_rule = $true
    }

    $rule.Profiles = 0x7FFFFFFF
    $rule.Protocol = 6
    $rule.LocalPorts = 5985
    $rule.RemotePorts = "*"
    $rule.LocalAddresses = "*"
    $rule.RemoteAddresses = "*"
    $rule.Enabled = $true
    $rule.Direction = 1
    $rule.Action = 1
    $rule.Grouping = "Windows Remote Management"

    If ($add_rule) {
        $fw.Rules.Add($rule)
    }

    Write-VerboseLog "HTTP firewall rule $($rule.Name) updated"
}
Function EnableIis {
    Write-VerboseLog "Installing IIS features"
    #IIS Configuration
    if (Test-Path -Path iis_ran.log) {
        Write-Host "IIS Services already installed..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole
    Write-VerboseLog "IIS-WebServerRole installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServer
    Write-VerboseLog "IIS-WebServer installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-CommonHttpFeatures
    Write-VerboseLog "IIS-CommonHttpFeatures installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-HttpErrors
    Write-VerboseLog "IIS-HttpErrors installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-HttpRedirect
    Write-VerboseLog "IIS-HttpRedirect installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-ApplicationDevelopment
    Write-VerboseLog "IIS-ApplicationDevelopment installed"
    Enable-WindowsOptionalFeature -online -FeatureName NetFx4Extended-ASPNET45
    Write-VerboseLog "NetFx4Extended-ASPNET45 installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-NetFxExtensibility45
    Write-VerboseLog "IIS-NetFxExtensibility45 installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-HealthAndDiagnostics
    Write-VerboseLog "IIS-HealthAndDiagnostics installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-HttpLogging
    Write-VerboseLog "IIS-HttpLogging installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-LoggingLibraries
    Write-VerboseLog "IIS-LoggingLibraries installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-RequestMonitor
    Write-VerboseLog "IIS-RequestMonitor installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-HttpTracing
    Write-VerboseLog "IIS-HttpTracing installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-Security
    Write-VerboseLog "IIS-Security installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-RequestFiltering
    Write-VerboseLog "IIS-RequestFiltering installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-Performance
    Write-VerboseLog "IIS-Performance installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerManagementTools
    Write-VerboseLog "IIS-WebServerManagementTools installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-IIS6ManagementCompatibility
    Write-VerboseLog "IIS-IIS6ManagementCompatibility installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-Metabase
    Write-VerboseLog "IIS-Metabase installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-ManagementConsole
    Write-VerboseLog "IIS-ManagementConsole installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-BasicAuthentication
    Write-VerboseLog "IIS-BasicAuthentication installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-WindowsAuthentication
    Write-VerboseLog "IIS-WindowsAuthentication installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-StaticContent
    Write-VerboseLog "IIS-StaticContent installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-DefaultDocument
    Write-VerboseLog "IIS-DefaultDocument installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebSockets
    Write-VerboseLog "IIS-WebSockets installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-ApplicationInit
    Write-VerboseLog "IIS-ApplicationInit installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-ISAPIExtensions
    Write-VerboseLog "IIS-ISAPIExtensions installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-ISAPIFilter
    Write-VerboseLog "IIS-ISAPIFilter installed"
    Enable-WindowsOptionalFeature -Online -FeatureName IIS-HttpCompressionStatic
    Write-VerboseLog "IIS-HttpCompressionStatic installed"

    Enable-WindowsOptionalFeature -Online -FeatureName IIS-ASPNET45
    Write-VerboseLog "IIS-ASPNET45 installed"

    New-item -itemtype file iis_ran.log | Out-Null
    Write-VerboseLog "IIS Features installed"
    return 0
}

Function EnableWebPlatformInstaller {
    Write-VerboseLog "Installing Web Platform Installer"
    if (Test-Path -Path wpi_ran.log) {
        Write-VerboseLog "Web Platform Services already installed..."
        return 1
    }
    #Web Platfrom Installer Section
    $url = "https://go.microsoft.com/fwlink/?LinkId=287166"

    $start_time = Get-Date
    try {
        mkdir 'c:\temp'
    }
    catch { }

    $output = "c:\temp\WebPlatformInstaller_amd64_en-US.msi"
    $start_time = Get-Date
    Invoke-WebRequest -Uri $url -OutFile $output
    Write-VerboseLog  "Time taken: $((Get-Date).Subtract($start_time).Seconds) second(s)"
    Start-Process msiexec.exe -Wait -ArgumentList '/I  c:\temp\WebPlatformInstaller_amd64_en-US.msi  /quiet'
    New-item -itemtype file wpi_ran.log | Out-Null
    Write-VerboseLog "Web Platform Installer installed"
    return 0
}
Function InstallationIISWebSite {
    if (Test-Path -Path InstallationIISWebSite.log) {
        Write-Host "InstallationIISWebSite already installed..." | Out-File $OutputFileLocation -Append
        return 1
    }

    ##Create Folder advisoryhome.com in C:\inetpub\
    ##For PWS Create a advisoryhome.com folder
    ##For PWS $ChildPath should be advisoryhome.com
	##$Ip = Test-Connection $env:COMPUTERNAME -count 1 | select Ipv4Address
	$Ip=(Test-Connection -ComputerName $env:computername -count 1).ipv4address.IPAddressToString

    $SiteName = "EDGAdminPortal"
    ##$HostName = "advisoryhome.com"
    $ChildPath = "Publish"
    $SiteFolder = Join-Path -Path 'C:\inetpub\' -ChildPath $ChildPath
    New-WebSite -Name $SiteName -PhysicalPath $SiteFolder -Force -IPAddress $Ip
	
    # Port 80
    Write-VerboseLog "WebBinding set on port 80"
	
	$BackgroundSiteName = "BackgroundApplication"
	$BackgroundAppPool = "BackgroundAppPool"
    $BackgroundChildPath = "Publish_HangFire"
    $BackgroundSiteFolder = Join-Path -Path 'C:\inetpub\' -ChildPath $BackgroundChildPath
    New-WebSite -Name $BackgroundSiteName -PhysicalPath $BackgroundSiteFolder -Port 50 -IPAddress $Ip -Force
	

	
    Write-VerboseLog "Set website at Port 50"
	##$DefaultSite = "Default Web Site"
	##New-WebBinding -Name "Default Web Site"   -Port 80 -Protocol http -Force

    Write-VerboseLog "WebBinding set on port 50"

    #################################################
    # *** Commented temporary by Andrei request *** #
    #################################################

    # Port 443
    # New-WebBinding -Name $SiteName -HostHeader "advisoryhome.com" -IPAddress * -Port 443 -Protocol https
    # $getChildItem = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object {$_.Subject -match 'advisoryhome.com, O="CoreLogic, Inc.", L=Irvine, S=California, C=US'}
    # $certPath = "Cert:\LocalMachine\My\$($getChildItem.Thumbprint)"
    # $providerPath = 'IIS:\SSLBindings\0.0.0.0!443' ##Binding to all IP addresses
    # Get-Item $certPath | New-Item $providerPath
    # Get-WebBinding
    # Write-VerboseLog "WebBinding set on port 443"


    ##Press Windows+R key and type inetmgr.
    ##This will open up the IIS.
    ##Refresh Sites folder, present under Application Pools and then expand it.
    ##You should see a Default Web Site.
    ##Right Click on Default Web Site and then Click on Explore
    ##It will navigate to the root folder(wwwroot or advisoryhome.com).
    New-item -itemtype file InstallationIISWebSite.log | Out-Null
    Write-VerboseLog "IIS Web site was installed - success"
    return 0
}

Function getMetricbeat{
	if (Test-Path -Path Metricbeat.log) {
        Write-Host "Metricbeat already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
	    Write-VerboseLog "Get Metricbeat from the Bucket"
		 $curl = $(curl -UseBasicParsing -Headers @{"Metadata-Flavor"="Google"} "http://metadata.google.internal/computeMetadata/v1/instance/attributes/env?alt=json").Content
		$env = $curl.replace('"', "")

    if ($env -eq "sbx") {
        $global:bucket = 'files-sbx'
    }
    elseif ($env -eq "dev") {
        $global:bucket = 'files-sbx'
    }
    elseif ($env -eq "uat") {
        $global:bucket = 'clgx-advisorypor-cache-files-uat'
    }
    elseif ($env -eq "reg" -or $env -eq "drg") {
        $env = 'reg'
        $global:bucket = 'clgx-advisorypor-cache-files-reg'
    }
    else {
        Write-VerboseLog "Environment set doesn't match any Bucket: $env"
    }

	$SecretsPath = "C:\Secrets"
	$global:IWSmetricbeatSystemYml = "ADVQN1VPWBPOR10_System.yml"
	$global:IWSmetricbeatYml = "ADVQN1VPWBPOR10_Metricbeat.yml"
	
    gsutil -m cp "gs://$global:bucket/Secrets/$global:IWSmetricbeatSystemYml" $SecretsPath
    ##Rename-Item -Path "C:\Secrets\ADVQN1VPWBPOR10_System.yml" -NewName "$SecretsPath\System.yml"
    Rename-Item -Path "$SecretsPath\$global:IWSmetricbeatSystemYml" -NewName "$SecretsPath\System.yml"
	
    gsutil -m cp "gs://$global:bucket/Secrets/$global:IWSmetricbeatYml" $SecretsPath
    ##Rename-Item -Path "C:\Secrets\ADVQN1VPWBPOR10_Metricbeat.yml" -NewName "$SecretsPath\Metricbeat.yml"
    Rename-Item -Path "$SecretsPath\$global:IWSmetricbeatYml" -NewName "$SecretsPath\Metricbeat.yml"
    New-item -itemtype file getMetricbeat.log | Out-Null
    Write-VerboseLog "Get Metricbeat from the Bucket - successful"
    return 0
}

Function getManifest {
    if (Test-Path -Path getManifest.log) {
        Write-Host "getManifest already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Get Manifest from the Bucket"

    $curl = $(curl -UseBasicParsing -Headers @{"Metadata-Flavor"="Google"} "http://metadata.google.internal/computeMetadata/v1/instance/attributes/env?alt=json").Content
    $env = $curl.replace('"', "")

    if ($env -eq "sbx") {
        $global:bucket = 'files-sbx'
    }
    elseif ($env -eq "dev") {
        $global:bucket = 'files-sbx'
    }
    elseif ($env -eq "uat") {
        $global:bucket = 'clgx-advisorypor-cache-files-uat'
    }
    elseif ($env -eq "reg" -or $env -eq "drg") {
        $env = 'reg'
        $global:bucket = 'clgx-advisorypor-cache-files-reg'
    }
    else {
        Write-VerboseLog "Environment set doesn't match any Bucket: $env"
    }

    $secrets = 'Secrets'
    $SecretsPath = new-item $env:SystemDrive:\$secrets -itemtype directory -force
    $manifest = '-manifest.csv'

    gsutil -m cp "gs://$global:bucket/Manifests/$env$manifest" $SecretsPath
    $global:manifestfile = "$env$manifest"

    New-item -itemtype file getManifest.log | Out-Null
    Write-VerboseLog "Get Manifest from the Bucket - successful"
    return 0
}

Function Initvars {
    if (Test-Path -Path Initvars.log) {
        Write-Host "Initvars already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Set Init vars from manifest file"

    $varPath = "C:\Secrets\$global:manifestfile"
    $vars = import-csv -Delimiter ","  -Header 'component', 'variable', 'bucketfolder', 'artifactcontainer', 'artifact' -Path $varPath

    $computername=$env:computername

    foreach($var in $vars )
    {
        if ($computername.contains($var.component.ToUpper())) {
            if ($var.variable -eq "IWStoken") {
                $global:IWStoken = $var.artifact
            }
            if ($var.variable -eq "IWSusers") {
                $global:IWSusers = $var.artifact
            }
            if ($var.variable -eq "msitrunk") {
                $global:msitrunk = $var.artifactcontainer.replace('.zip', "")
            }
            if ($var.variable -eq "NDP462DevPack") {
                $global:NDP462DevPack = $var.artifact
            }
            if ($var.variable -eq "vcredist") {
                $global:vcredist = $var.artifact
            }
            if ($var.variable -eq "AccessDatabaseEngine") {
                $global:AccessDatabaseEngine = $var.artifactcontainer.replace('.zip', "")
            }
            if ($var.variable -eq "AccessDatabaseEngine") {
                $global:AccessDBinstall = $var.artifact
            }
            if ($var.variable -eq "ISWebConfig") {
                $global:ISWebConfig = $var.artifactcontainer.replace('.zip', "")
            }
            if ($var.variable -eq "ISConfig") {
                $global:ISConfig = $var.artifactcontainer.replace('.zip', "")
            }
            if ($var.variable -eq "FilewatcherConfig") {
                $global:FilewatcherConfig = $var.artifactcontainer.replace('.zip', "")
            }
			 if ($var.variable -eq "FilewatcherUtilityConfig") {
			     Write-VerboseLog "Inside FilewatcherUtilityConfig"

                $global:FilewatcherUtilityConfig = $var.artifactcontainer.replace('.zip', "")
            }
            if ($var.variable -eq "ntrights") {
                $global:ntrights = $var.artifactcontainer.replace('.zip', "")
            }
			if ($var.variable -eq "IWSmetricbeatSystemYml") {
					$global:IWSmetricbeatSystemYml = $var.artifact
				}
			if ($var.variable -eq "IWSmetricbeatYml") {
					$global:IWSmetricbeatYml = $var.artifact
				}
			if ($var.variable -eq "IWSdotnethosting") {
                $global:IWSdotnethosting = $var.artifact
            }
			if ($var.variable -eq "EDGAdminWebConfig") {
                $global:EDGAdminWebConfig = $var.artifactcontainer.replace('.zip', "")
            }
			if ($var.variable -eq "EDGAdminappSettings") {
                $global:EDGAdminappSettings = $var.artifactcontainer.replace('.zip', "")  
            }
			if ($var.variable -eq "NDP462DevPackDotNetCore") {
                $global:NDP462DevPackDotNetCore = $var.artifact
            }
			if ($var.variable -eq "EDGBackgroundServiceWebconfig") {
                $global:EDGBackgroundServiceWebconfig = $var.artifactcontainer.replace('.zip', "") 
            }
			if ($var.variable -eq "EDGAdminViewWebConfig") {
                $global:EDGAdminViewWebConfig = $var.artifactcontainer.replace('.zip', "") 
            }
			if ($var.variable -eq "ISRazorEngine") {
                $global:ISRazorEngine = $var.artifactcontainer.replace('.zip', "") 
			}
			if ($var.variable -eq "ISSystemWebRazor") {
                $global:ISSystemWebRazor = $var.artifactcontainer.replace('.zip', "") 
			}
			if ($var.variable -eq "SystemDataSqlClient") {
                $global:SystemDataSqlClient = $var.artifactcontainer.replace('.zip', "") 
			}
        
        }
    }

    New-item -itemtype file Initvars.log | Out-Null
    Write-VerboseLog "Set Init vars from manifest file - successful"
    return 0
}

Function getFilesFromBucket {
    if (Test-Path -Path getFilesFromBucket.log) {
        Write-Host "getFilesFromBucket already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Getting files from the Bucket"

    $varPath = "C:\Secrets\$global:manifestfile"
    $vars = import-csv -Delimiter ","  -Header 'component', 'variable', 'bucketfolder', 'artifactcontainer', 'artifact' -Path $varPath
    $clmsi = 'cl-msi'

    $computername=$env:computername

    $clmsiPath = new-item $env:SystemDrive:\$clmsi -itemtype directory -force
    $SecretsPath = 'C:\Secrets'

    foreach($var in $vars )
    {	
		Write-VerboseLog "var is - $var.artifactcontainer" 
		Write-VerboseLog "computrname is - $computername"
        if ($computername.contains($var.component.ToUpper())) {
            foreach ($path in $var.bucketfolder)
            {
                if ($var.bucketfolder -eq 'Secrets') {
                    if ($var.artifact.contains(".csv")) {
                        $bucketfolder=$var.bucketfolder
                        $artifact=$var.artifact
                        gsutil -m cp -r "gs://$global:bucket/$bucketfolder/$artifact" $SecretsPath
                    }
                }
                if ($var.artifact.contains(".exe")) {
                    $bucketfolder=$var.bucketfolder
                    $artifact=$var.artifact
					Write-VerboseLog "exe bucketfolder is $bucketfolder - " 
					Write-VerboseLog "exe artifact is $artifact - " 
                    gsutil -m cp -r "gs://$global:bucket/$bucketfolder/$artifact" $clmsiPath
                }
                if ($var.artifactcontainer.contains(".zip")) {
                    $bucketfolder=$var.bucketfolder
                    $artifact=$var.artifactcontainer
					Write-VerboseLog "bucketfolder is $bucketfolder - " 
					Write-VerboseLog "artifact is $artifact - " 
                    gsutil -m cp -r "gs://$global:bucket/$bucketfolder/$artifact" $clmsiPath
                }
            }
        }
    }
    
    New-item -itemtype file getFilesFromBucket.log | Out-Null
    Write-VerboseLog "Got files from the Bucket - successful"
    return 0
}

Function CreateUsers {
    if (Test-Path -Path CreateUsers.log) {
        Write-Host "CreateUsers already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }

    Write-VerboseLog "Creating users"
    # List of the variables stores in C:\Secrets\users.csv
    $SecretsPath = "C:\Secrets"
    $Users = import-csv $SecretsPath\$global:IWSusers

    # Create users if they don't exist( dont mangle existing permissions )
    foreach($user in $Users )
    {
    $adsi = [ADSI]"WinNT://$env:COMPUTERNAME"
    $existingUser = $adsi.Children | where {$_.SchemaClassName -eq 'user' -and $_.Name -eq $user.name }
    $existingGroup = $adsi.Children | where {$_.SchemaClassName -eq 'group' } | foreach { ($_.name)[0]}
        if ($existingUser -eq $null) {

            # skip for empty password, add domain user to the group
            #if ($user.password -eq "" -and $user.name.contains("\")) {
                if ($user.name.contains("\")) {
                    $username=$user.name
                    Write-VerboseLog "Password for user $username not found. Skip user creation"
                    Add-LocalGroupMember -Group $user.group -Member $user.name -Verbose -ErrorAction Continue
                }

                # create regular local users
                else
                {
                    Write-VerboseLog $("Creating user:"+$user.name)
                    $Password = $user.password | ConvertTo-SecureString -asPlainText -Force
                    New-LocalUser -Name $user.name -Password $Password -FullName $user.fullname -Description $user.description -PasswordNeverExpires -ErrorAction Continue
                }
            }

        # add local users to group
        if ($existingGroup -contains $user.group) {
            if ( -not ($user.name.contains("\"))) {
                Add-LocalGroupMember -Group $user.group -Member $user.name -Verbose -ErrorAction Continue
            }
        }

        # create new exta-group and add it into another group
        else
        {
            New-LocalGroup -Name $user.group
            Add-LocalGroupMember -Group $user.group -Member $user.name -Verbose -ErrorAction Continue
        }
    }

    New-item -itemtype file CreateUsers.log | Out-Null
    Write-VerboseLog "Users created - successful"
    return 0
}

Function UnzipFiles {
    if (Test-Path -Path UnzipFiles.log) {
        Write-Host "UnzipFiles already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Unziping archives"
    $FolderPath = "C:\cl-msi"
    $archives = Get-ChildItem -Path $FolderPath -Recurse -File
    foreach($archive in $archives ) 
    {
        if ($archive.Extension -eq ".zip") {
            New-Item -ItemType directory -Path $FolderPath\$($archive.BaseName) -Force
            Expand-Archive -Path $FolderPath\$archive -DestinationPath $FolderPath\$($archive.BaseName) -Force 
            Write-VerboseLog "$archive unzipped - successful" 
        }
    }
    New-item -itemtype file UnzipFiles.log | Out-Null
    Write-VerboseLog "Zip Archives unziped - successful"
    return 0
}

Function installMSI {
    if (Test-Path -Path installMSI.log) {
        Write-Host "installMSI already installed..." | Out-File $OutputFileLocation -Append
        return 1
    }
	try{
    Write-VerboseLog "Start to install MSI packages"
    #MSI Configuration and install
    $dirFiles = "C:\cl-msi\$global:msitrunk"
        #install to default folder
        Write-VerboseLog "install to default folder"
        $msiList = @(
            'qbo.Setup.Core.msi',
			'qbo.Setup.Credit.msi',
			'Faslo.Setup.msi',
			'qbo.Setup.Mortgage.msi',
            'qbo.Setup.CoreWeb.msi',
            'qbo.Plugins.setup.msi',
            'AdvAdmin.Setup.msi',
            'ADV.Setup.Service.msi',
            'Filewatcher.Setup.msi',
			'FWUtility.Setup.msi',
			'BackgroundApp.Setup.msi',
			'EDG.AdminSetup.msi'
        )

        foreach ($msi in $msiList) {
            $install = Join-Path -Path $dirFiles -ChildPath $msi
			If($msi -eq 'BackgroundApp.Setup.msi')
			{	
				 Write-VerboseLog "Installation of the MSI packages - BackgroundApp.Setup.msi"

				 Start-Process msiexec.exe -Wait -ArgumentList "/I  $install /qn TARGETSITE=/LM/W3SVC/3 TARGETAPPPOOL=BackgroundAppPool" 
				 
				 ##Start-Process "msiexec.exe" -ArgumentList "/I $install",'/qn',"TARGETSITE='/LM/W3SVC/3'","TARGETAPPPOOL='BackgroundAppPool'" -Wait
				 
				 Write-VerboseLog "Installation of the MSI packages - BackgroundApp.Setup.msi -complted"
			}
			elseif($msi -eq 'EDG.AdminSetup.msi')                 
			{	
				 Start-Process msiexec.exe -Wait -ArgumentList "/I  $install /qn TARGETSITE=/LM/W3SVC/2 TARGETAPPPOOL=DefaultAppPool" 

			
				 ##"msiexec.exe" -ArgumentList "/I $install",'/qn',"TARGETSITE='/LM/W3SVC/2'","TARGETAPPPOOL='DefaultAppPool'" -Wait

			}
			
			else
			{
				Start-Process "msiexec.exe" -ArgumentList "/I $install",'/qn' -Wait
			}

        }
		}
		catch {
			Write-VerboseLog $_.Exception.Message
		}

    Write-VerboseLog "Installation of the MSI packages - successful"
    New-item -itemtype file installMSI.log | Out-Null
    return 0
}

Function installExe {
    if (Test-Path -Path installExe.log) {
        Write-Host "installExe already installed..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Installing Exe packages"            
    
    Start-Process -Wait -FilePath "c:\cl-msi\$global:NDP462DevPack" -ArgumentList "/S" -PassThru
    Start-Process -Wait -FilePath "C:\cl-msi\$global:vcredist" -ArgumentList "/install /passive /norestart" -PassThru -Verb RunAs
    Start-Process -Wait -FilePath "C:\cl-msi\$global:AccessDatabaseEngine\$global:AccessDBinstall" -ArgumentList "/Q" -PassThru -Verb RunAs
	Start-Process -Wait -FilePath "C:\cl-msi\$global:IWSdotnethosting" -ArgumentList "/Q" -PassThru -Verb RunAs
    Start-Process -Wait -FilePath "c:\cl-msi\$global:NDP462DevPackDotNetCore" -ArgumentList "/Q" -PassThru -Verb RunAs
    New-item -itemtype file installExe.log | Out-Null
    Write-VerboseLog "Installation of the EXE packages - successful"
    return 0
}

Function CreateFolderIIS {
    if (Test-Path -Path CreateFolderIIS.log) {
        Write-Host "CreateFolderIIS already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }

    Write-VerboseLog "Create folder"
    new-item c:\inetpub\wwwroot\Logs -itemtype directory
    new-item c:\inetpub\wwwroot\Upload -itemtype directory
    new-item c:\inetpub\wwwroot\Upload\Decrypted -itemtype directory
    new-item c:\inetpub\wwwroot\Upload\Encrypted -itemtype directory
    new-item c:\inetpub\wwwroot\Upload\FileControl -itemtype directory
    new-item c:\inetpub\wwwroot\Upload\Import -itemtype directory
    new-item c:\inetpub\wwwroot\Upload\Report -itemtype directory
    new-item c:\inetpub\wwwroot\Upload\Spreadsheet -itemtype directory
    new-item c:\inetpub\wwwroot\Upload\Temp -itemtype directory
    new-item c:\inetpub\wwwroot\Upload\TempImportFiles -itemtype directory
    new-item c:\inetpub\wwwroot\Config -itemtype directory
	new-item c:\inetpub\Publish -itemtype directory
	new-item c:\inetpub\Publish_HangFire -itemtype directory

    New-item -itemtype file CreateFolderIIS.log | Out-Null
    Write-VerboseLog "All folder created - success"
    return 0
}

Function DeleteFiles {
    if (Test-Path -Path DeleteFiles.log) {
        Write-Host "DeleteFiles already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }

    Write-VerboseLog "Delete Files"
    Remove-Item -path "C:\inetpub\wwwroot\*" -include "*.config" -Recurse
    Remove-Item "C:\inetpub\wwwroot\bin\Microsoft.SqlServer.DTSRuntimeWrap.DLL" -Force -ErrorAction Continue
    Remove-Item "C:\inetpub\wwwroot\bin\ChilkatDotNet4.dll" -Force -ErrorAction Continue
    New-item -itemtype file DeleteFiles.log | Out-Null
    Write-VerboseLog "Delete files - success"
    return 0
}

Function CopyFiles {
    if (Test-Path -Path CopyFiles.log) {
        Write-Host "CopyFiles already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }

    Write-VerboseLog "Copy a file to the specified directory"
    Copy-Item "C:\cl-msi\$global:ISWebConfig\web.config" -Destination "C:\inetpub\wwwroot"
    Copy-Item "C:\cl-msi\$global:ISConfig\Config\*" -Destination "C:\inetpub\wwwroot\Config"
    Copy-Item "C:\cl-msi\$global:FilewatcherConfig\FileWatcherService.exe.config" -Destination "C:\inetpub\wwwroot\FileWatcher"
	Copy-Item "C:\cl-msi\$global:FilewatcherUtilityConfig\FWUtility.exe.config" -Destination "C:\inetpub\wwwroot\FWUtility"
    Copy-Item "C:\cl-msi\$global:FilewatcherConfig\FileWatcherService.exe.config" -Destination "C:\inetpub\wwwroot\FWUtility"
    #opy-Item "C:\Secrets\System.yml" -Destination "C:\ProgramData\chocolatey\lib\metricbeat\tools\modules.d"
    #Copy-Item "C:\Secrets\Metricbeat.yml" -Destination "C:\ProgramData\chocolatey\lib\metricbeat\tools"
	Copy-Item "C:\cl-msi\$global:EDGAdminWebConfig\web.config" -Destination "C:\inetpub\Publish"
	Copy-Item "C:\cl-msi\$global:EDGAdminappSettings\appsettings.json" -Destination "C:\inetpub\Publish_HangFire"
	Copy-Item "C:\cl-msi\$global:EDGBackgroundServiceWebconfig\web.config" -Destination "C:\inetpub\Publish_HangFire"
	Copy-Item "C:\cl-msi\$global:EDGAdminViewWebConfig\web.config" -Destination "C:\inetpub\Publish\Views"
	if (-not(Test-Path -LiteralPath C:\inetpub\wwwroot\bin\RazorEngine.dll -PathType Leaf))
	{
		Copy-Item "C:\cl-msi\$global:ISRazorEngine\RazorEngine.dll" -Destination "C:\inetpub\wwwroot\bin"
	}
	if (-not(Test-Path -LiteralPath C:\inetpub\wwwroot\bin\System.Web.Razor.dll -PathType Leaf))
	{
		Copy-Item "C:\cl-msi\$global:ISSystemWebRazor\System.Web.Razor.dll" -Destination "C:\inetpub\wwwroot\bin"
	}
	if (-not(Test-Path -LiteralPath C:\inetpub\Publish_HangFire\runtimes\win\lib\netstandard2.0\System.Data.SqlClient.dll -PathType Leaf))
	{
		Copy-Item "C:\cl-msi\$global:SystemDataSqlClient\System.Data.SqlClient.dll" -Destination "C:\inetpub\Publish_HangFire\runtimes\win\lib\netstandard2.0\"
	}

	
    New-item -itemtype file CopyFiles.log | Out-Null
    Write-VerboseLog "Copy a file to the specified directory - success"
    return 0
}
Function CopyMetricbeatFiles {
    if (Test-Path -Path CopyMetricbeatFiles.log) {
        Write-Host "CopyMetricbeatFiles already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
	
    Write-VerboseLog "Copy a Metric beat files to the specified directory"
    Copy-Item "C:\Secrets\System.yml" -Destination $global:MetricbeatSystemYmlPath
    Copy-Item "C:\Secrets\Metricbeat.yml" -Destination $global:MetricbeatYmlPath
	
    New-item -itemtype file CopyMetricbeatFiles.log | Out-Null
    Write-VerboseLog "Copy Metricbeat to the specified directory - success"
    return 0
}
Function RestartMetricbeat {
	 if (Test-Path -Path RestartMetricbeat.log) {
        Write-Host "RestartMetricbeat already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Stopping Metricbeat Service"
	Stop-Service -Name "Metricbeat"
	
	Write-VerboseLog "Starting Metricbeat Service"
	Start-Service -Name "Metricbeat"
	
	New-item -itemtype file RestartMetricbeat.log | Out-Null
    Write-VerboseLog "Restarting Metricbeat  Service - successful"
    return 0
	
}
Function RestartW3SVC{
	 if (Test-Path -Path RestartW3SVC.log) {
        Write-Host "RestartW3SVC already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Stopping W3SVC"
	Stop-Service -Name "W3SVC"
	
	Write-VerboseLog "Starting W3SVC Service"
	Start-Service -Name "W3SVC"
	
	New-item -itemtype file RestartW3SVC.log | Out-Null
    Write-VerboseLog "Restarting RestartW3PService - successful"
    return 0
	
}
Function SetDBToken {
    if (Test-Path -Path SetDBToken.log) {
        Write-Host "SetDBToken already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Start to set DB tokens"
    
    $token = "C:\Secrets\$global:IWStoken"
    $csv = import-csv -Delimiter ","  -Header 'Env', 'Key', 'Value' -Path $token
    $curl = $(curl -UseBasicParsing -Headers @{"Metadata-Flavor"="Google"} "http://metadata.google.internal/computeMetadata/v1/instance/attributes/env?alt=json").Content 
    $env = $curl.replace('"', "")
    $configPath = @(
        'C:\inetpub\wwwroot\FileWatcher\FileWatcherService.exe.config',
		'C:\inetpub\wwwroot\FWUtility\FileWatcherService.exe.config',
		'C:\inetpub\wwwroot\FWUtility\FWUtility.exe.config',
        'C:\inetpub\wwwroot\Config\ConnectionStrings.config',
        'C:\inetpub\wwwroot\Config\AppSettings.config',
        'C:\inetpub\wwwroot\Config\FileObject.config',
        'C:\inetpub\wwwroot\web.config',
		'C:\inetpub\Publish\web.config',
		'C:\inetpub\Publish_Hangfire\appsettings.json',
		'C:\inetpub\wwwroot\Templates\FileWatcher\CLEAR.UserNotification.cshtml',
		'C:\inetpub\wwwroot\Templates\FileWatcher\UserNotification.cshtml',
		'C:\inetpub\wwwroot\Skins\Faslo\faslo.siteStructure.xml'
    )    
    foreach($path in $configPath )
        {
            foreach($row in $csv )	
            {   
                if ($row.Env.ToUpper() -eq $env.ToUpper()) {
					if($row.Key -eq "<MetricbeatYmlPath/>")
					{
						$global:MetricbeatYmlPath = $row.Value
						Write-VerboseLog $global:MetricbeatYmlPath
					}
					if($row.Key -eq "<MetricbeatSystemYmlPath/>")
					{
						$global:MetricbeatSystemYmlPath = $row.Value
						Write-VerboseLog $global:MetricbeatSystemYmlPath
					}
					((Get-Content -path $path -Raw) -replace $row.Key, $row.Value ) | Set-Content -Path $path
					}
            }
            Write-Host "Tokens were replaced in $path"	
        }

    New-item -itemtype file SetDBToken.log | Out-Null
    Write-VerboseLog "Set DB token - successful"
    return 0
}

Function SetPermisionsFolders {
    if (Test-Path -Path SetPermisionsFolders.log) {
        Write-Host "SetPermisionsFolders already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }

    # For 'C:\inetpub\wwwroot'
    $wwwrootPath = "C:\inetpub\wwwroot"
    $aclGroup = "IIS_IUSRS"
    foreach ($group in $aclGroup){
        $rights = "Modify"
        $inheritSettings = 'Containerinherit, ObjectInherit' #Controls how permissions are inherited by children
        $propagarionSettings = 'None'
        $ruleType = 'Allow'
        $acl = Get-Acl $wwwrootPath
        $perm = $group, $rights, $inheritSettings, $propagarionSettings, $ruleType
        $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
        $acl.SetAccessRule($rule)
        $acl | Set-Acl -Path $wwwrootPath
        Write-VerboseLog "Setup permisions to $wwwrootPath for $group Group"
    }

    $wwwrootPath = "C:\inetpub\wwwroot"
    $aclGroup = "Administrators"
    foreach ($group in $aclGroup){
        $rights = "FullControl"
        $inheritSettings = 'Containerinherit, ObjectInherit' #Controls how permissions are inherited by children
        $propagarionSettings = 'None'
        $ruleType = 'Allow'
        $acl = Get-Acl $wwwrootPath
        $perm = $group, $rights, $inheritSettings, $propagarionSettings, $ruleType
        $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
        $acl.SetAccessRule($rule)
        $acl | Set-Acl -Path $wwwrootPath
        Write-VerboseLog "Setup permisions to $wwwrootPath for $group Group"
    }

    # For 'C:\inetpub\wwwroot\Logs'
    $LogsPath = "C:\inetpub\wwwroot\Logs"
    $aclGroup = "IIS_IUSRS", "Administrators", "Users"
    foreach ($group in $aclGroup){
        $rights = "FullControl"
        $inheritSettings = 'Containerinherit, ObjectInherit' #Controls how permissions are inherited by children
        $propagarionSettings = 'None'
        $ruleType = 'Allow'
        $acl = Get-Acl $LogsPath
        $perm = $group, $rights, $inheritSettings, $propagarionSettings, $ruleType
        $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
        $acl.SetAccessRule($rule)
        $acl | Set-Acl -Path $LogsPath
        Write-VerboseLog "Setup permisions to $LogsPath for $group Group"
    }

    # For 'C:\inetpub\wwwroot\FileWatcher'
    $wwwrootPath = "C:\inetpub\wwwroot\FileWatcher"
    $aclGroup = "isc\isce-sa-AdvisoryWeb"
    foreach ($group in $aclGroup){
        $rights = "FullControl"
        $inheritSettings = 'Containerinherit, ObjectInherit' #Controls how permissions are inherited by children
        $propagarionSettings = 'None'
        $ruleType = 'Allow'
        $acl = Get-Acl $wwwrootPath
        $perm = $group, $rights, $inheritSettings, $propagarionSettings, $ruleType
        $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
        $acl.SetAccessRule($rule)
        $acl | Set-Acl -Path $wwwrootPath
        Write-VerboseLog "Setup permisions to $wwwrootPath for 'isc\isce-sa-AdvisoryWeb' user"
    }
	# For 'C:\inetpub\Publish'
    $adminPortalPath = "C:\inetpub\Publish"
    $aclGroup = "IIS_IUSRS"
    foreach ($group in $aclGroup){
        $rights = "Modify"
        $inheritSettings = 'Containerinherit, ObjectInherit' #Controls how permissions are inherited by children
        $propagarionSettings = 'None'
        $ruleType = 'Allow'
        $acl = Get-Acl $adminPortalPath
        $perm = $group, $rights, $inheritSettings, $propagarionSettings, $ruleType
        $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
        $acl.SetAccessRule($rule)
        $acl | Set-Acl -Path $adminPortalPath
        Write-VerboseLog "Setup permisions to $adminPortalPath for $group Group"
    }

    $adminPortalPath = "C:\inetpub\Publish_Hangfire"
    $aclGroup = "Administrators"
    foreach ($group in $aclGroup){
        $rights = "FullControl"
        $inheritSettings = 'Containerinherit, ObjectInherit' #Controls how permissions are inherited by children
        $propagarionSettings = 'None'
        $ruleType = 'Allow'
        $acl = Get-Acl $adminPortalPath
        $perm = $group, $rights, $inheritSettings, $propagarionSettings, $ruleType
        $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
        $acl.SetAccessRule($rule)
        $acl | Set-Acl -Path $adminPortalPath
        Write-VerboseLog "Setup permisions to $adminPortalPath for $group Group"
    }

    New-item -itemtype file SetPermisionsFolders.log | Out-Null
    Write-VerboseLog "Setup permision - successful"
    return 0
}

Function EnableNuget {
    #Nuget Section
    Write-VerboseLog "installing Nuget"
    if (Test-Path -Path nuget_ran.log) {
        Write-VerboseLog "Nuget Services already installed..."
        return 1
    }
    try {
        mkdir 'c:\temp'
    }
    catch { }
    $sourceNugetExe = "https://dist.nuget.org/win-x86-commandline/latest/nuget.exe"
    $targetNugetExe = "c:\temp\nuget.exe"
    Invoke-WebRequest $sourceNugetExe -OutFile $targetNugetExe
    Set-Alias nuget $targetNugetExe -Scope Global -Verbose
    New-item -itemtype file nuget_ran.log | Out-Null
    Write-VerboseLog "Nuget installed"
    return 0

}

Function joinDomain {

    if (Test-Path -Path joinDomain.log) {
        Write-VerboseLog "Joining to the Domain already made..."
        return 1
    }
    Write-VerboseLog "Joining to the Domain"

    if ((gwmi win32_computersystem).partofdomain -eq $false) {
        $constLength = 15
        # $hostname = "taxuc1guwebds01"

        $domains = @{
            Flood = "FDS";
            CoreLogic                = "COR";
            Advisory_Data_Valuations = "ADV";
            AgentAchieve             = "AGT";
            A_La_Mode                = "ALM";
            Basis_100                = "CIS";
            BPO_Services             = "BPO";
            Build_and_Release        = "BNR";
            Capital_Markets          = "CIS";
            Case_Schiller            = "CSW";
            CDS_Business_Mapping     = "CBM";
            Claims_Services_CMAX     = "CMX";
            Cognizant                = "CGN";
            Collateral_Solutions     = "COS";
            Commericial_Tax_Service  = "TAX"
        }

        $gcp_regions = @(
            "asia-east1",
            "asia-east2",
            "asia-northeast1",
            "asia-northeast2",
            "asia-northeast3",
            "asia-south1",
            "asia-southeast1",
            "australia-southeast1",
            "europe-north1",
            "europe-west1",
            "europe-west2",
            "europe-west3",
            "europe-west4",
            "europe-west6",
            "northamerica-northeast1",
            "southamerica-east1",
            "us-central1",
            "us-east1",
            "us-east4",
            "us-west1",
            "us-west2",
            "us-west3",
            "us-west4"
        )

        $environments = @{
            Production     = "P";
            QA             = "Q";
            Development    = "D";
            DR             = "R";
            Customer_Stage = "S";
            BETA           = "B";
            UAT            = "U";
            Integration    = "I";
            Pre_Production = "O";
            Test           = "T";
            Hardening      = "H"
        }

        $domain_vals = $domains.Values -join "|"
        $short_regions = @()
        foreach ( $region in $gcp_regions) {
            $region = $region -split "-"
            $short_regions += $region[0][0], $region[1][0], $region[1][-1] -join ""
        }
        $r_short_regions = $short_regions -join "|"
        $r_environments = $environments.Values -join ""

        $r = "^(?<domain>($domain_vals))(?<short_region>($r_short_regions))g(?<environment>[$r_environments])(?<app_id>[a-z]{5})(?<app_enum>[0-9]{2})$"
        filter Check-Length {
            if ($_.length -eq $constLength) { return 1 }
            else { return 0 }
        }
        $ComputerName = $env:computername
        if ([bool]($ComputerName | Check-Length)) {
            Write-Host "Hostname: $ComputerName"
            Write-Host "Hostname length is ok"
            if ( $ComputerName -match $r) {
                Write-Host "Hostname is ok"
                Write-Host "Discovered elements:"
                Write-Host "Domain: "$Matches.domain
                Write-Host "Short region: "$Matches.short_region
                Write-Host "Environment: "$Matches.environment
                Write-Host "Application idetifier: "$Matches.app_id
                Write-Host "Application enumerator: "$Matches.app_enum
            }
            else {
                Write-Host "Hostname didn't match pattern: $r"
                exit 1
            }
        } else { Write-Host "Hostname didn't satisfy length restrictions"; exit 1 }

        # parse environment name
        $curl = $(curl -UseBasicParsing -Headers @{"Metadata-Flavor"="Google"} "http://metadata.google.internal/computeMetadata/v1/instance/attributes/env?alt=json").Content
        $env = $curl.replace('"', "")

        # set DNS default value
        if ($env -eq "sbx") {
            Write-VerboseLog "Picking up DNS IP for us-west1 region"
            $primaryIP='172.28.226.34'
            $secondaryIP='172.28.226.35'

            $iscMember = 'isc\cets-gg-sso-isc-gcp-advisorypor-app.nonprod-devsecops'
        }

        elseif ($env -eq "dev" -or $env -eq "uat") {
            Write-VerboseLog "Picking up IP for us-central1 region"

            $primaryIP='172.28.242.34'
            $secondaryIP='172.28.242.35'

            $iscMember = 'isc\cets-gg-sso-isc-gcp-advisorypor-app.nonprod-devsecops'
        }

        elseif ($env -eq "reg") {
            Write-VerboseLog "Picking up DNS IP for us-central1 region"

            $primaryIP='172.28.242.34'
            $secondaryIP='172.28.242.35'

            $iscMember = 'isc\cets-gg-sso-isc-gcp-advisorypor-app.prod-devsecops'
        }

        elseif ($env -eq "drg") {
            Write-VerboseLog "Picking up DNS IP for us-west1 region"

            $primaryIP='172.28.226.34'
            $secondaryIP='172.28.226.35'
            
            $iscMember = 'isc\cets-gg-sso-isc-gcp-advisorypor-app.prod-devsecops'
        }

        else
        {
            Write-VerboseLog "Environment not set. Picking up the default DNS IP"
            $primaryIP='10.216.0.12'
            $secondaryIP='10.232.0.12'
	    
	    $iscMember = 'isc\cets-gg-sso-isc-gcp-advisorypor-app.nonprod-devsecops'
        }

        # dns severs on domain controllers - may or may not vary between teams
        netsh interface ipv4 set dnsservers name= "Ethernet" source= Static address= $primaryIP

        # dns servers on domain controllers - may or may not vary between teams
        netsh interface ipv4 add dnsservers name= "Ethernet" address= $secondaryIP

        # full path of the ISCP domain creds are the service account being used to join (may prompt for a pw, teams may be given a per team SA) ou's may change per team
        $password = "${domain_admin_password}" | ConvertTo-SecureString -Force -AsPlainText
        $username = 'isc\ISC-SA-BUILD-ADV150'
        $credential = New-Object System.Management.Automation.PSCredential($username,$password)
        Add-Computer -DomainName infosolco.com -Credential $credential -OUpath "OU=Servers,OU=GCP,DC=InfoSolCo,DC=Com"
        write-host "Joined Domain"

        # add the cloud ops group to the Administrators local group on PC
        Add-LocalGroupMember -Group "Administrators" -Member "isc\cets-gg-sso-isc-gcp-cloudops-global"

        # add per-team group of admins to Administrators on local PC, this could be env-specific
        Add-LocalGroupMember -Group "Administrators" -Member $iscMember
    }

    #To remove the VM from the domain use:
    #Remove-Computer -UnjoinDomainCredential $creds -Confirm:$false -Force -Restart

    New-item -itemtype file joinDomain.log | Out-Null
    Write-VerboseLog "Join to the Domain - successful"

    # mandatory reboot to apply changes
    shutdown /r /t 20 #wait 20 seconds # /p # immediate # /f for force, might lose data

    exit 0
}

Function setPassword {

    if (Test-Path -Path password_ran.log) {
        Write-VerboseLog "Password already changed..."
        return 1
    }
    Write-VerboseLog "Setting admin password"
    net user Administrator "${admin_password}"
    net user Administrator /active:yes
    netsh advfirewall firewall add rule name="WinRM in" protocol=TCP dir=in profile=any localport=5985 remoteip=any localip=any action=allow
    $admin = [ADSI]("WinNT://./administrator, user")
    $admin.SetPassword("${admin_password}")
    Write-VerboseLog "Done Setting admin password"
    New-item -itemtype file password_ran.log | Out-Null
}

Function InstallPscx {
    if (Test-Path -Path pscx_ran.log) {
        Write-VerboseLog "Pscx already changed..."
        return 1
    }
    Write-VerboseLog "Installing Pscx"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
    Install-Module -name Pscx -Force -AllowClobber
    Write-VerboseLog "Pscx installation complete"
    New-item -itemtype file pscx_ran.log | Out-Null
}

Function HostFilewatcherService {
    if (Test-Path -Path HostFilewatcherService.log) {
        Write-Host "HostFilewatcherService already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Start to host Filewatcher Service"

    # Set credentials
    $SecretsPath = 'C:\Secrets'
    $Users = import-csv $SecretsPath\$global:IWSusers
    foreach($user in $Users ) {
        if ($user.name -eq "isc\FasloEvents") {
            $name=$user.name
            #$password="${isc_advisoryweb_password}"
            $password=$user.password

            # Grant 'Log on as a Service' rights
            $SourceDir="C:\cl-msi\$global:ntrights"
            Start-Process -FilePath $SourceDir\msi_ntrights.exe -ArgumentList "-u $name +r SeServiceLogonRight" -Wait

            # Set credentials
            $FWPwd = ConvertTo-SecureString -String $password -AsPlainText -Force
            $Credentials = New-Object System.Management.Automation.PSCredential($name, $FWPwd)
        }
    }

	#virtualdirectory Site App pool

    # Create Service
    $FileWatcherPath = 'C:\inetpub\wwwroot\Filewatcher\FileWatcherService.exe'
    $params = @{
        Name = "FileWatcherService"
        BinaryPathName = $FileWatcherPath
        DisplayName = "FileWatcherService"
        StartupType = "Automatic"
        Description = "This is a FileWatcher service."
        Credential = $Credentials
    }
    New-Service @params
    Start-Service -Name "FileWatcherService"
    
    New-item -itemtype file HostFilewatcherService.log | Out-Null
    Write-VerboseLog "Start to host Filewatcher Service - successful"
    return 0
}
Function HostFilewatcherUtility {
    if (Test-Path -Path HostFilewatcherUtilityService.log) {
        Write-Host "HostFilewatcherUtilityService already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Start to host Filewatcher Utility Service"

    # Set credentials
    $SecretsPath = 'C:\Secrets'
    $Users = import-csv $SecretsPath\$global:IWSusers
    foreach($user in $Users ) {
        if ($user.name -eq "isc\FasloEvents") {
            $name=$user.name
            #$password="${isc_advisoryweb_password}"
            $password=$user.password

            # Grant 'Log on as a Service' rights
            ##$SourceDir="C:\cl-msi\$global:ntrights"
            ##Start-Process -FilePath $SourceDir\msi_ntrights.exe -ArgumentList "-u $name +r SeServiceLogonRight" -Wait

            # Set credentials
            $FWPwd = ConvertTo-SecureString -String $password -AsPlainText -Force
            $Credentials = New-Object System.Management.Automation.PSCredential($name, $FWPwd)
        }
    }

	#virtualdirectory Site App pool

    # Create Service
    $FileWatcherUtilityPath = 'C:\inetpub\wwwroot\FWUtility\FWUtility.exe'
    $params = @{
        Name = "FWUtility"
        BinaryPathName = $FileWatcherUtilityPath
        DisplayName = "FWUtility"
        StartupType = "Automatic"
        Description = "This is a FileWatcher utility service."
        Credential = $Credentials
    }
    New-Service @params
    Start-Service -Name "FWUtility"
    
    New-item -itemtype file HostFilewatcherUtilityService.log | Out-Null
    Write-VerboseLog "Start to host HostFilewatcherUtility Service - successful"
    return 0
}

Function CreateBackgroundAppPool{
	 if (Test-Path -Path BackgroundAppPool.log) {
			Write-Host "BackgroundAppPool already complete..." | Out-File $OutputFileLocation -Append
			return 1
		}
		
	Import-Module WebAdministration

	$appPoolName     = "BackgroundAppPool"
	$appPoolFullName = "IIS:\AppPools\$appPoolName"

	if(!(Test-Path $appPoolFullName)) {
		New-WebAppPool $appPoolName -Force
		}

    Set-ItemProperty $appPoolFullName -Name startMode -Value AlwaysRunning -force
    Set-ItemProperty $appPoolFullName -Name processModel.idleTimeout -Value ( [TimeSpan]::FromMinutes(0)) -force
	
	Write-VerboseLog "BackgroundAppPool created"

	
	New-item -itemtype file BackgroundAppPool.log | Out-Null

	return 0
}
Function DefaultAppPool {
    if (Test-Path -Path DefaultAppPool.log) {
        Write-Host "DefaultAppPool already complete..." | Out-File $OutputFileLocation -Append
        return 1
    }
    Write-VerboseLog "Start to set isc\isce-sa-AdvisoryWeb user in the DefaultAppPool"

    $SecretsPath = "C:\Secrets\$global:IWSusers"
    $Users = import-csv -Delimiter ","  -Header 'name', 'share', 'permissions', 'description', 'password', 'group', 'fullname' -Path $SecretsPath

    Import-Module WebAdministration
    
    foreach($user in $Users )
    {
        if ($user.name -eq "isc\isce-sa-AdvisoryWeb") {
            $username=$user.name
            $usrpassword=$user.password

            $identity = @{
                identitytype="SpecificUser";
                username=$username;
                #password="${isc_advisoryweb_password}"
                password=$usrpassword
            }
            Set-ItemProperty -Path "IIS:\AppPools\DefaultAppPool" -name "processModel" -value $identity -force
			Set-ItemProperty -Path "IIS:\AppPools\BackgroundAppPool" -name "processModel" -value $identity -force
        }
    }
    New-item -itemtype file DefaultAppPool.log | Out-Null
    Write-VerboseLog "Set isc\isce-sa-AdvisoryWeb user in the DefaultAppPool - successful"
    return 0
}

# Setup error handling.
Trap {
    $_
    Exit 1
}
$ErrorActionPreference = "Stop"

Write-VerboseLog "Start up script started"

setPassword
joinDomain

#mount additional disk and format
Write-VerboseLog "Adding any new disks"
$newdisk = @(get-disk | Where-Object partitionstyle -eq 'raw')
$Labels = @('Backup', 'Data', 'System')

for ($i = 0; $i -lt $newdisk.Count ; $i++) {

    $disknum = $newdisk[$i].Number
    $dl = get-Disk $disknum |
    Initialize-Disk -PartitionStyle GPT -PassThru |
    New-Partition -AssignDriveLetter -UseMaximumSize
    Format-Volume -driveletter $dl.Driveletter -FileSystem NTFS -NewFileSystemLabel $Labels[$i] -Confirm:$false

}
Write-VerboseLog "Complete adding new disks"

Write-VerboseLog " - Installing Misc Services....Inside metadata script ps1."
if (Test-Path -Path join_ran.log) {
    Write-VerboseLog "Misc Services already installed..."

}
#setting this here until each block has it's own individual check of whether a component has been completed
else {


    Write-VerboseLog " - Installing Services..."
    try {
        #in case this fails...
        Rename-Item -Path "C:\Program Files\Google\Compute Engine\sysprep\setupcomplete.cmd" -NewName "ren_setupcomplete.cmd_ren"
    }
    catch {

    }


    # Get the ID and security principal of the current user account
    $myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $myWindowsPrincipal = new-object System.Security.Principal.WindowsPrincipal($myWindowsID)

    # Get the security principal for the Administrator role
    $adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator

    # Check to see if we are currently running "as Administrator"
    if (-Not $myWindowsPrincipal.IsInRole($adminRole)) {
        Write-VerboseLog "ERROR: You need elevated Administrator privileges in order to run this script."
        Write-VerboseLog "       Start Windows PowerShell by using the Run as Administrator option."
        Exit 2
    }
    Write-VerboseLog "Done setting up admin password"

    $EventSource = $MyInvocation.MyCommand.Name
    If (-Not $EventSource) {
        $EventSource = "Powershell CLI"
    }

    If ([System.Diagnostics.EventLog]::Exists('Application') -eq $False -or [System.Diagnostics.EventLog]::SourceExists($EventSource) -eq $False) {
        New-EventLog -LogName Application -Source $EventSource
    }
    Write-VerboseLog "Configuring Powershell--but why? This script would not be running if this process is required"
    # Detect PowerShell version.
    If ($PSVersionTable.PSVersion.Major -lt 3) {
        Write-VerboseLog "PowerShell version 3 or higher is required."
        return 1
    }

    # Find and start the WinRM service.
    Write-VerboseLog "Verifying WinRM service."
    If (!(Get-Service "WinRM")) {
        Write-VerboseLog "Unable to find the WinRM service."
        return 1
    }
    ElseIf ((Get-Service "WinRM").Status -ne "Running") {
        Write-VerboseLog "Setting WinRM service to start automatically on boot."
        Set-Service -Name "WinRM" -StartupType Automatic
        Write-VerboseLog "Set WinRM service to start automatically on boot."
        Write-VerboseLog "Starting WinRM service."
        Start-Service -Name "WinRM" -ErrorAction Stop
        Write-VerboseLog "Started WinRM service."

    }
    Write-VerboseLog "Done setting WinRM"

    # WinRM should be running; check that we have a PS session config.
    If (!(Get-PSSessionConfiguration -Verbose:$false) -or (!(Get-ChildItem WSMan:\localhost\Listener))) {
        If ($SkipNetworkProfileCheck) {
            Write-VerboseLog "Enabling PS Remoting without checking Network profile."
            Enable-PSRemoting -SkipNetworkProfileCheck -Force -ErrorAction Stop
            Write-VerboseLog "Enabled PS Remoting without checking Network profile."
        }
        Else {
            Write-VerboseLog "Enabling PS Remoting."
            Enable-PSRemoting -Force -ErrorAction Stop
            Write-VerboseLog "Enabled PS Remoting."
        }
    }
    Else {
        Write-VerboseLog "PS Remoting is already enabled."
    }

    Write-VerboseLog "Ensure LocalAccountTokenFilterPolicy is set to 1"
    # https://github.com/ansible/ansible/issues/42978
    $token_path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
    $token_prop_name = "LocalAccountTokenFilterPolicy"
    $token_key = Get-Item -Path $token_path
    $token_value = $token_key.GetValue($token_prop_name, $null)
    if ($token_value -ne 1) {
        Write-VerboseLog "Setting LocalAccountTOkenFilterPolicy to 1"
        if ($null -ne $token_value) {
            Remove-ItemProperty -Path $token_path -Name $token_prop_name
        }
        New-ItemProperty -Path $token_path -Name $token_prop_name -Value 1 -PropertyType DWORD > $null
    }
    Write-VerboseLog "LocalAccountTokenFilterPolicy check complete"
    Write-VerboseLog "Make sure there is a SSL listener."
    $listeners = Get-ChildItem WSMan:\localhost\Listener
    If (!($listeners | Where { $_.Keys -like "TRANSPORT=HTTPS" })) {
        # We cannot use New-SelfSignedCertificate on 2012R2 and earlier
        $thumbprint = New-LegacySelfSignedCert -SubjectName $SubjectName -ValidDays $CertValidityDays
        Write-HostLog "Self-signed SSL certificate generated; thumbprint: $thumbprint"

        # Create the hashtables of settings to be used.
        $valueset = @{
            Hostname              = $SubjectName
            CertificateThumbprint = $thumbprint
        }

        $selectorset = @{
            Transport = "HTTPS"
            Address   = "*"
        }

        Write-VerboseLog "Enabling SSL listener."
        New-WSManInstance -ResourceURI 'winrm/config/Listener' -SelectorSet $selectorset -ValueSet $valueset
        Write-VerboseLog "Enabled SSL listener."
    }
    Else {
        Write-VerboseLog "SSL listener is already active."

        # Force a new SSL cert on Listener if the $ForceNewSSLCert
        If ($ForceNewSSLCert) {

            # We cannot use New-SelfSignedCertificate on 2012R2 and earlier
            $thumbprint = New-LegacySelfSignedCert -SubjectName $SubjectName -ValidDays $CertValidityDays
            Write-VerboseLog "Self-signed SSL certificate generated; thumbprint: $thumbprint"

            $valueset = @{
                CertificateThumbprint = $thumbprint
                Hostname              = $SubjectName
            }

            # Delete the listener for SSL
            $selectorset = @{
                Address   = "*"
                Transport = "HTTPS"
            }
            Remove-WSManInstance -ResourceURI 'winrm/config/Listener' -SelectorSet $selectorset

            # Add new Listener with new SSL cert
            New-WSManInstance -ResourceURI 'winrm/config/Listener' -SelectorSet $selectorset -ValueSet $valueset
        }
    }
    Write-VerboseLog "Listener Check complete"
    Write-VerboseLog "Check for basic authentication."

    $basicAuthSetting = Get-ChildItem WSMan:\localhost\Service\Auth | Where-Object { $_.Name -eq "Basic" }

    If ($DisableBasicAuth) {
        If (($basicAuthSetting.Value) -eq $true) {
            Write-VerboseLog "Disabling basic auth support."
            Set-Item -Path "WSMan:\localhost\Service\Auth\Basic" -Value $false
            Write-VerboseLog "Disabled basic auth support."
        }
        Else {
            Write-VerboseLog "Basic auth is already disabled."
        }
    }
    Else {
        If (($basicAuthSetting.Value) -eq $false) {
            Write-VerboseLog "Enabling basic auth support."
            Set-Item -Path "WSMan:\localhost\Service\Auth\Basic" -Value $true
            Write-VerboseLog "Enabled basic auth support."
        }
        Else {
            Write-VerboseLog "Basic auth is already enabled."
        }
    }
    Write-VerboseLog "Basic Auth check complete"

    Write-VerboseLog "If EnableCredSSP if set to true"
    If ($EnableCredSSP) {
        # Check for CredSSP authentication
        $credsspAuthSetting = Get-ChildItem WSMan:\localhost\Service\Auth | Where { $_.Name -eq "CredSSP" }
        If (($credsspAuthSetting.Value) -eq $false) {
            Write-VerboseLog "Enabling CredSSP auth support."
            Enable-WSManCredSSP -role server -Force
            Write-VerboseLog "Enabled CredSSP auth support."
        }
    }

    Write-VerboseLog "EnableCredSSP complete"

    Write-VerboseLog "Check Global Http Firewall Access"
    If ($GlobalHttpFirewallAccess) {
        Enable-GlobalHttpFirewallAccess
    }

    # Configure firewall to allow WinRM HTTPS connections.
    $fwtest1 = netsh advfirewall firewall show rule name="Allow WinRM HTTPS"
    $fwtest2 = netsh advfirewall firewall show rule name="Allow WinRM HTTPS" profile=any
    If ($fwtest1.count -lt 5) {
        Write-VerboseLog "Adding firewall rule to allow WinRM HTTPS."
        netsh advfirewall firewall add rule profile=any name="Allow WinRM HTTPS" dir=in localport=5986 protocol=TCP action=allow
        Write-VerboseLog "Added firewall rule to allow WinRM HTTPS."
    }
    ElseIf (($fwtest1.count -ge 5) -and ($fwtest2.count -lt 5)) {
        Write-VerboseLog "Updating firewall rule to allow WinRM HTTPS for any profile."
        netsh advfirewall firewall set rule name="Allow WinRM HTTPS" new profile=any
        Write-VerboseLog "Updated firewall rule to allow WinRM HTTPS for any profile."
    }
    Else {
        Write-VerboseLog "Firewall rule already exists to allow WinRM HTTPS."
    }
    Write-VerboseLog "Global Http Firewall Access complete"

    Write-VerboseLog "Test a remoting connection to localhost, which should work."
    $httpResult = Invoke-Command -ComputerName "localhost" -ScriptBlock { $env:COMPUTERNAME } -ErrorVariable httpError -ErrorAction SilentlyContinue
    $httpsOptions = New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck

    $httpsResult = New-PSSession -UseSSL -ComputerName "localhost" -SessionOption $httpsOptions -ErrorVariable httpsError -ErrorAction SilentlyContinue

    If ($httpResult -and $httpsResult) {
        Write-VerboseLog "HTTP: Enabled | HTTPS: Enabled"
    }
    ElseIf ($httpsResult -and !$httpResult) {
        Write-VerboseLog "HTTP: Disabled | HTTPS: Enabled"
    }
    ElseIf ($httpResult -and !$httpsResult) {
        Write-VerboseLog "HTTP: Enabled | HTTPS: Disabled"
    }
    Else {
        Write-VerboseLog "Unable to establish an HTTP or HTTPS remoting session."
        Throw "Unable to establish an HTTP or HTTPS remoting session."
    }
    Write-VerboseLog "PS Remoting has been successfully configured for Ansible."

    New-item -itemtype file join_ran.log | Out-Null

    #Start-Sleep 360
    $reboot = 'true'


}

EnableIis
EnableWebPlatformInstaller
getManifest
getMetricbeat
Initvars
getFilesFromBucket
CreateUsers
UnzipFiles
CreateBackgroundAppPool
DefaultAppPool
CreateFolderIIS
InstallationIISWebSite
installMSI
installExe
RestartW3SVC
##CreateFolderIIS
DeleteFiles
CopyFiles
SetDBToken
CopyMetricbeatFiles
RestartMetricbeat
SetPermisionsFolders
InstallPscx
EnableNuget
HostFilewatcherService
HostFilewatcherUtility



if ($reboot -eq 'true') {
    Write-VerboseLog " - restart host ..."
    Restart-Computer -Force
}
else {
    Write-VerboseLog " - restart host not required ..."
    Write-VerboseLog "Exiting Startup script"
}
