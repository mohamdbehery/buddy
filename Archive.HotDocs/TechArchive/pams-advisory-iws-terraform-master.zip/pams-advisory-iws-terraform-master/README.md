## Requirement

 - Terraform v0.12
 - provider.google: version = "~> 3.11"
 - provider.google-beta: version = "~> 3.11"


## Section 1. Using this template
1. Source Control: Github
This assumes you already have a github repository you will be adding the new terraform script to. Make sure to create a new branch from the 'master' or 'development' branch. Branch from where you pan to merge directly to, don't attempt to do baseless merges. Clone the new branch to your local and open in your editor.
2. Copy template:
This template includes everything needed to create a Windows Web Server. You will need to copy over the entire folder for this to work properly. Copy the template over to your project folder. It is advised to create a folder named for the target system, and place this folder into that new folder. Get the latest Jenkinsfile from this repo at ..\pipeline\jenkins\jenkinsfile
3. Modify template
* variables.tf: no changes
* jenkinsfile: no changes
* outputs.tf: no changes
* meta-files folder: no changes to contents
* inventories folder: no changes to contents
* target-service.tf: rename file to something meaningful. No changes to contents
* environments: create folders per environment. i.e. sbx, dev, int, stg, uat, prd (rename env-name folder)
    * in environments/env-name folder, rename env-name.config to target environment (sbx, dev, int, stg, uat, prd)
    * in the environments/env-name folder, rename env-name.tfvars to target environment (sbx, dev, int, stg, uat, prd)
    * for above examples, use 'dev' as the env-name, so there will be environments/dev/dev.tfvars
        * in this dev.tfvars, look for variable values that are wrapped in double curly braces "{{}}"
        * this indicates a value to populate. the text in the curly brace identities the values.
            * i.e. `region = "{{region to provision servers}}"`
            * if using us-central1, then the line will be `region = "us-central1"`
            * most values are found on the GCP project
    * in the environments/env-name folder, rename the regionname.config and regionname.tfvars to a region used to provision the servers
        * i.e. us-central1.config and us-central1.tfvars
        * create new files for all the regions required to support the infrastructure deployment
    * in this us-central1.tfvars, look for variable values that are wrapped in double curly braces "{{}}"
        * Make sure to provide an unique migname that follows enterprise arch naming conventions

4. Test script
You can run this script locally against a sandbox environment. The commands in Section 2 describe how to execute the script. Use this to identify any issues with the script
5. Check into Source Control
Check in your branch and create a pull request. It is advised to merge these changes into the master branch. This will function from another branch, but could create confusion, especially is someone needs to maintain or execute the scripts. Use pull requests to prevent bugs or issues.
6. Create Jenkins pipeline job. See the instructions [here](https://confluence.corelogic.net/display/CO/Adopt+the+IaC+Jenkins+Pipeline)
7. Execute the pipeline!

---

## Section 2. calling from the CLI
This script creates  managed instance groups in required regions.
Configuration details are passed to terraform script using .tfvar files.
For required regions create a per region .tfvars files and pass this to the tf
script. Refer to iis.tfvars and variable.tf for details of each variable.

To run the script , follow below steps

run terraform command as below

`terraform init -backend-config="../environments/{environmentname}/sbx.config" -backend-config="../environments/{environmentname}/{target-region}.config"`

- this command will initialize the backend data for the environment where the server will be provisioned. The environment config file holds data that is explicit for the environment. In this example, the persistent storage name is in the sandbox config file. All the state files for the servers will be saved to this one persistent storage. The region config file holds the path to the statefile for the  servers.


`terraform plan -var-file="../environments/{environmentname}/sbx.tfvars" -var-file="../environments/{environmentname}/us-central1.tfvars"`

### Sandbox
`terraform init -backend-config="environments/sbx/sbx.config" -backend-config="environments/sbx/us-west1.config"`

`terraform plan -var-file="environments/sbx/sbx.tfvars" -var-file="environments/sbx/us-west1.tfvars"`

`terraform apply -var-file="environments/sbx/sbx.tfvars" -var-file="environments/sbx/us-west1.tfvars"`

`terraform destroy -var-file="environments/sbx/sbx.tfvars" -var-file="environments/sbx/us-west1.tfvars"`

### DEV

`terraform init -backend-config="environments/dev/dev.config" -backend-config="environments/dev/us-central1.config"`

`terraform plan -var-file="environments/dev/dev.tfvars" -var-file="environments/dev/us-central1.tfvars"`

`terraform apply -var-file="environments/dev/dev.tfvars" -var-file="environments/dev/us-central1.tfvars"`

`terraform destroy -var-file="environments/dev/dev.tfvars" -var-file="environments/dev/us-central1.tfvars"`

### UAT

`terraform init -backend-config="environments/uat/uat.config" -backend-config="environments/uat/us-central1.config"`

`terraform plan -var-file="environments/uat/uat.tfvars" -var-file="environments/uat/us-central1.tfvars"`

`terraform apply -var-file="environments/uat/uat.tfvars" -var-file="environments/uat/us-central1.tfvars"`

`terraform destroy -var-file="environments/uat/uat.tfvars" -var-file="environments/uat/us-central1.tfvars"`

### PROD

`terraform init -backend-config="environments/reg/reg.config" -backend-config="environments/reg/us-central1.config"`

`terraform plan -var-file="environments/reg/reg.tfvars" -var-file="environments/reg/us-central1.tfvars"`

`terraform apply -var-file="environments/reg/reg.tfvars" -var-file="environments/reg/us-central1.tfvars"`

`terraform destroy -var-file="environments/reg/reg.tfvars" -var-file="environments/reg/us-central1.tfvars"`

### DRG

`terraform init -backend-config="environments/drg/drg.config" -backend-config="environments/drg/us-west1.config"`

`terraform plan -var-file="environments/drg/drg.tfvars" -var-file="environments/drg/us-west1.tfvars"`

`terraform apply -var-file="environments/drg/drg.tfvars" -var-file="environments/drg/us-west1.tfvars"`

`terraform destroy -var-file="environments/drg/drg.tfvars" -var-file="environments/drg/us-west1.tfvars"`

TBD

- state file for each of this workspace is stored  in '{persistent bucket}/{fullpath}/default.tfstate' bucket
